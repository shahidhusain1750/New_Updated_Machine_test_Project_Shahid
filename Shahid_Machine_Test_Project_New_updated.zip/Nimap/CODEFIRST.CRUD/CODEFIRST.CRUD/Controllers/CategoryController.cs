﻿using CODEFIRST.CRUD.DTO;
using CODEFIRST.CRUD.Interface;
using CODEFIRST.CRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CODEFIRST.CRUD.Controllers
{
    public class CategoryController : Controller
    {
        #region private field read-only field
        private readonly IProductService _productRep;
        private readonly ICategoryService _categoryRep;

        public CategoryController(IProductService productRep, ICategoryService categoryRepo)
        {
            _productRep = productRep;
            _categoryRep = categoryRepo;
        }
        #endregion

        #region Index
        public async Task<IActionResult> Index()
        {
            var category = await _categoryRep.GetAll();
            return View(category);
        }
        #endregion

        #region [Create] - GetRequest
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            // Fetch categories from the repository
            var categories = await _categoryRep.GetAll(); // Ensure GetAll is async in ICategoryRep
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName");
            return View();
        }
        #endregion

        #region [Create] - PostRequest
        [HttpPost]
        public async Task<IActionResult> Create(CategoryDTO categoryDTO)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Convert CategoryDTO to Category entity
                    var category = new Category
                    {
                        CategoryName = categoryDTO.CategoryName,
                        CategoryId = categoryDTO.CategoryId // Optional if auto-generated
                    };

                    await _categoryRep.Add(category);

                    // Redirect to ProductController's Index action after successfully adding a category
                    return RedirectToAction("Index", "Product"); // Adjusted here
                }
            }
            catch (Exception ex)
            {
                ModelState.Clear();
                ModelState.AddModelError(string.Empty, "An error occurred while creating the category.");
            }

            // Repopulate the category list in case of a model error
            var categories = await _categoryRep.GetAll();
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName");

            return View(categoryDTO); // Ensure the model passed here is correct
        }
        #endregion

        #region [Edit] - GetRequest
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var category = await _categoryRep.GetById(id);
            if (category == null)
            {
                return NotFound();
            }

            // Populate CategoryDTO with the current category details
            var categoryDTO = new CategoryDTO
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName
            };

            // Get all categories and populate the dropdown
            var categories = await _categoryRep.GetAll();
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName", categoryDTO.CategoryId);

            return View(categoryDTO);
        }
        #endregion

        #region Edit - PostRequest
        [HttpPost]
        public async Task<IActionResult> Edit(CategoryDTO categoryDTO)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Check if categoryDTO.CategoryId exists in the repository
                    var existingCategory = await _categoryRep.GetById(categoryDTO.CategoryId);

                    if (existingCategory != null)
                    {
                        // Update the existing category's name
                        existingCategory.CategoryName = categoryDTO.CategoryName;

                        // Save the updated category back to the repository
                        await _categoryRep.Update(existingCategory);
                    }
                    else
                    {
                        // If category does not exist, consider it as a new entry (text input)
                        var newCategory = new Category
                        {
                            CategoryName = categoryDTO.CategoryName // The input from the user
                        };

                        // Add the new category to the repository
                        await _categoryRep.Add(newCategory);
                    }

                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                ModelState.AddModelError(string.Empty, "An error occurred while updating the category.");
            }

            // Repopulate the category list in case of a model error
            var categories = await _categoryRep.GetAll();
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName", categoryDTO.CategoryId);

            return View(categoryDTO);
        }
        #endregion

        #region [Delete] - GetRequest
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var category = await _categoryRep.GetById(id);
            if (category == null)
            {
                return NotFound();
            }

            // Map the Category model to CategoryDTO
            var categoryDTO = new CategoryDTO
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName
            };

            // Return the CategoryDTO to the view for confirmation
            return View(categoryDTO);
        }
        #endregion

        #region Delete - PostRequest
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                var category = await _categoryRep.GetById(id);
                if (category == null)
                {
                    return NotFound();
                }

                // Check if any products are using this category
                var productsUsingCategory = await _productRep.GetByCategoryId(id); // Ensure this returns IEnumerable<ProductDTO>

                if (productsUsingCategory != null && productsUsingCategory.Any())  // Check if it’s not null and has elements
                {
                    ModelState.AddModelError(string.Empty, "This category cannot be deleted because it is associated with products.");
                    return View(new CategoryDTO { CategoryId = category.CategoryId, CategoryName = category.CategoryName });
                }

                // Delete the category if no products are using it
                await _categoryRep.Delete(id);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "An error occurred while deleting the category.");
                return View();
            }
        }
        #endregion

        #region ExtraMethod - Get - DeleteCategoryOnly
        /*[HttpGet]
        public async Task<IActionResult> DeleteCategoryOnly(int id)
        {
            var category = await _categoryRep.GetById(id);
            if (category == null)
            {
                return NotFound();
            }

            var categoryDTO = new CategoryDTO
            {
                CategoryId = category.CategoryId,
                CategoryName = category.CategoryName
            };

            return View("DeleteCategoryOnly", categoryDTO); // Create a new view for this confirmation
        }*/
        #endregion Extra Methods for DeleteCategoryOnly

        #region ExtraMethod Post - DeleteCategoryOnlyConfirmed
        /*[HttpPost, ActionName("DeleteCategoryOnly")]
        public async Task<IActionResult> DeleteCategoryOnlyConfirmed(int id)
        {
            try
            {
                var category = await _categoryRep.GetById(id);
                if (category == null)
                {
                    return NotFound();
                }

                // Ensure the category exists and delete only the category association, not the products
                await _categoryRep.DeleteCategoryOnly(id);

                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "An error occurred while deleting the category association.");
                return View("DeleteCategoryOnly");
            }
        }*/
        #endregion
    }
}