﻿using CODEFIRST.CRUD.DTO;
using CODEFIRST.CRUD.Interface;
using CODEFIRST.CRUD.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace CODEFIRST.CRUD.Controllers
{
    public class ProductController : Controller
    {
        #region private field read-only field
        private readonly IProductService _productRep;
        private readonly ICategoryService _categoryRepo;
        #endregion

        #region Constructor
        public ProductController(IProductService productRep, ICategoryService categoryRepo)
        {
            _productRep = productRep;
            _categoryRepo = categoryRepo;
        }
        #endregion

        #region GetAll - (Index method) | Pagination & Search - Implementation - [Main Project]
        public async Task<IActionResult> Index(string searchTerm, int pageNumber = 1, int pageSize = 10)
        {
            // Debugging to ensure the pageNumber updates correctly
            //Console.WriteLine($"Current Page Number: {pageNumber}");

            var products = await _productRep.GetPaginatedProducts(pageNumber, pageSize, searchTerm);
            var totalProducts = await _productRep.GetTotalProductsCount();

            ViewBag.PageSize = pageSize; // Store the page size in ViewBag
            ViewBag.TotalPages = (int)Math.Ceiling((double)totalProducts / pageSize);
            ViewBag.SearchTerm = searchTerm;

            return View(products);
        }
        #endregion

        #region [Create] - GetRequest
        [HttpGet]
        public async Task<IActionResult> Create()
        {
            // Fetch categories from the repository
            var categories = await _categoryRepo.GetAll(); // Ensure GetAll is async in ICategoryRep
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName");
            return View();
        }
        #endregion

        #region [Create] - PostRequest
        [HttpPost]
        public async Task<IActionResult> Create(ProductDTO productDTO)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Convert ProductDTO to Product entity
                    var product = new Product
                    {
                        ProductName = productDTO.ProductName,
                        CategoryId = productDTO.CategoryId
                    };

                    await _productRep.Add(product);
                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, "An error occurred while creating the product.");
            }

            // Repopulate the category list in case of a model error
            var categories = await _categoryRepo.GetAll();
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName");

            return View(productDTO);
        }
        #endregion

        #region [Edit] - GetRequest
        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var product = await _productRep.GetById(id);
            if (product == null)
            {
                return NotFound();
            }
            var productDTO = new ProductDTO
            {
                ProductId = product.ProductId,
                ProductName = product.ProductName,
                CategoryId = product.CategoryId,
                CategoryName = product.CategoryName
            };
            var categories = await _categoryRepo.GetAll();
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName", productDTO.CategoryId);
            return View(productDTO);
        }
        #endregion

        #region Edit - PostRequest
        [HttpPost]
        public async Task<IActionResult> Edit(ProductDTO productDTO)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    // Fetch the existing product from the repository
                    var existingProduct = await _productRep.GetById(productDTO.ProductId);
                    if (existingProduct == null)
                    {
                        return NotFound();
                    }

                    // Update the properties of the existing product
                    existingProduct.ProductName = productDTO.ProductName;
                    existingProduct.CategoryId = productDTO.CategoryId;

                    // Check if CategoryName needs to be updated
                    if (!string.IsNullOrEmpty(productDTO.CategoryName))
                    {
                        var existingCategory = await _categoryRepo.GetById(productDTO.CategoryId);
                        if (existingCategory != null)
                        {
                            existingCategory.CategoryName = productDTO.CategoryName;
                            await _categoryRepo.Update(existingCategory); // Ensure your repository has this method
                        }
                    }

                    // Save the updated product back to the repository
                    await _productRep.Update(existingProduct);

                    return RedirectToAction(nameof(Index));
                }
            }
            catch (Exception ex)
            {
                // Log the exception (optional)
                ModelState.AddModelError(string.Empty, "An error occurred while updating the product.");
            }

            // Repopulate the category list in case of a model error
            var categories = await _categoryRepo.GetAll();
            ViewBag.CategoryList = new SelectList(categories, "CategoryId", "CategoryName", productDTO.CategoryId);

            return View(productDTO);
        }
        #endregion


        #region Delete - GetRequest
        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            // Fetch the product from the repository by its ID
            var product = await _productRep.GetById(id);
            if (product == null)
            {
                return NotFound();
            }

            // Return the Delete view with the product details for confirmation
            return View(product);
        }
        #endregion

        #region Delete - PostRequest
        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            try
            {
                // Fetch the product from the repository to confirm it exists
                var product = await _productRep.GetById(id);
                if (product == null)
                {
                    return NotFound();
                }

                // Delete the product from the repository
                await _productRep.Delete(id);

                // Redirect to the index page after successful deletion
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                // Log the exception and display an error message if needed
                ModelState.AddModelError(string.Empty, "An error occurred while deleting the product.");
                return View();
            }
        }
        #endregion
    }
}