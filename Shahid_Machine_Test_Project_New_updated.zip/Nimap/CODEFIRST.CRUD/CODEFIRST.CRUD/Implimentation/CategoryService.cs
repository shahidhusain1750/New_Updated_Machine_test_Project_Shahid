﻿using CODEFIRST.CRUD.DTO;
using CODEFIRST.CRUD.Interface;
using CODEFIRST.CRUD.Models;
using Microsoft.EntityFrameworkCore;

namespace CODEFIRST.CRUD.Implimentation
{
    public class CategoryService : ICategoryService
    {
        #region private field for db access
        private readonly MyAppDbContext _context;
        #endregion

        #region constructor for accessing the field and inilizing
        public CategoryService(MyAppDbContext context)
        {
            _context = context;
        }
        #endregion

        #region GetAll
        public async Task<IEnumerable<CategoryDTO>> GetAll()
        {
            var categories = await _context.Categories.ToListAsync();

            // Map Category entities to CategoryDTO objects
            var categoryDTOs = categories.Select(c => new CategoryDTO
            {
                CategoryId = c.CategoryId,
                CategoryName = c.CategoryName
            }).ToList();

            return categoryDTOs;
        }
        #endregion

        #region Add
        public async Task Add(Category category)
        {
            await _context.Categories.AddAsync(category);
            await Save();

        }
        #endregion

        #region GetById
        public async Task<Category> GetById(int id)
        {
            return await _context.Categories.FindAsync(id);
        }
        #endregion

        #region Update
        public async Task Update(Category model)
        {
            var category = await _context.Categories.FindAsync(model.CategoryId);
            if (category != null)
            {
                category.CategoryName = model.CategoryName;
                _context.Update(category);
                await Save();
            }
        }
        #endregion

        #region Delete
        public async Task Delete(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category != null)
            {
                _context.Categories.Remove(category);
                await Save();
            }
        }
        #endregion

        #region Extra Method for Delete category Only
        public async Task DeleteCategoryOnly(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category != null)
            {
                category.CategoryId = id; // Detach the category from products
                await Save(); // Update to remove association
            }
        }
        #endregion 

        #region Private SaveChanges Method
        private async Task Save()
        {
            await _context.SaveChangesAsync();
        }
        #endregion
    }
}
