﻿using CODEFIRST.CRUD.DTO;
using CODEFIRST.CRUD.Models;
using X.PagedList;

namespace CODEFIRST.CRUD.Interface
{
    public interface IProductService
    {
        #region GetAll()
        Task<IEnumerable<ProductDTO>> GetAll();
        #endregion

        #region Add
        Task Add(Product product);
        #endregion

        #region GetById()
        Task<ProductDTO?> GetById(int id);
        #endregion

        #region Update()
        Task Update(ProductDTO existingProduct);
        #endregion

        #region Delete()
        Task Delete(int id);
        #endregion

        #region GetPaginatedProducts
        Task<IPagedList<ProductDTO>> GetPaginatedProducts(int pageNumber, int pageSize, string searchTerm);
        #endregion

        #region GetTotalProductsCount
        public Task<int> GetTotalProductsCount();
        #endregion

        #region SearchProducts Based on ProductName
        Task<IEnumerable<ProductDTO>> SearchProductsBaseOnProductName(string searchTerm);
        #endregion

        //extra method
        #region GetByCategoryId
        Task<IEnumerable<ProductDTO>> GetByCategoryId(int categoryId);
        #endregion

    }
}
