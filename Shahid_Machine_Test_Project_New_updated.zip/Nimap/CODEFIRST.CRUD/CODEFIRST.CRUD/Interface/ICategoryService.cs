﻿using CODEFIRST.CRUD.DTO;
using CODEFIRST.CRUD.Models;

namespace CODEFIRST.CRUD.Interface
{
    public interface ICategoryService
    {
        #region GetAllCategory
        Task<IEnumerable<CategoryDTO>> GetAll();
        #endregion

        #region AddCategory
        Task Add(Category category);
        #endregion

        #region GetCategoryById
        Task<Category> GetById(int id);
        #endregion

        #region UpdateCatgory
        Task Update(Category category);
        #endregion

        #region DeleteCategory
        Task Delete(int id);
        #endregion

        #region Extra Method for DeleteCategoryOnly
        Task DeleteCategoryOnly(int id);

        #endregion Delete CategoryOnly

    }
}
